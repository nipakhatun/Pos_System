<?php include 'inc\header.php';?>
        <?php
            if(!isset($_GET['catid'])||$_GET['catid']==NULL){
                echo"<script>window.location = 'catlist.php';</script>";
            }else{
                $id=$_GET['catid'];
            }
        ?>

        <div class="grid_10">
		
            <div class="box round first grid">
                <h2>Update Product Information</h2>
                <div>
                   <?php
                       if ($_SERVER['REQUEST_METHOD']=='POST') {
                            $category=$_POST['pr_category'];
                            $product_id=$_POST['pr_code'];
                            $name=$_POST['pr_name'];
                            $pr_description=$_POST['pr_description'];
                            $suplr_name=$_POST['suplr_name'];
                            $memo_no=$_POST['memo_no'];
                            $quantity=$_POST['quantity'];
                            $datepicker=$_POST['datepicker'];
                            $org_price=$_POST['org_price'];
                            $pr_costing=$_POST['pr_costing'];
                            $sell_price=$_POST['sell_price'];
                          
                            
                            
                            $category=mysqli_real_escape_string($db->link,$category);
                            $product_id=mysqli_real_escape_string($db->link,$product_id);
                            $name=mysqli_real_escape_string($db->link,$name);
                            $pr_description=mysqli_real_escape_string($db->link,$pr_description);
                            $suplr_name=mysqli_real_escape_string($db->link,$suplr_name);
                            $memo_no=mysqli_real_escape_string($db->link, $memo_no);
                            $quantity=mysqli_real_escape_string($db->link, $quantity);
                            $datepicker=mysqli_real_escape_string($db->link,$datepicker);
                            $org_price=mysqli_real_escape_string($db->link, $org_price);
                            $pr_costing=mysqli_real_escape_string($db->link,$pr_costing);
                            $sell_price=mysqli_real_escape_string($db->link,$sell_price);


                            if (empty( $category)) {
                              echo "<div class='alert alert-warning'>
                                             <strong>Warning!</strong> Field must not be empty.
                                        </div>";
                            }else{
                                 $query="UPDATE tbl_product SET pr_category='$category', pr_code='$product_id',pr_name='$name', pr_description='$pr_description',suplr_name='$suplr_name',memo_no='$memo_no', quantity='$quantity', datepicker='$datepicker', org_price='$org_price', pr_costing='$pr_costing', sell_price='$sell_price' WHERE pr_code='$id'";
                                 $result=$db->update($query);
                                 if ($result) {
                                     echo "<div class='alert alert-success'>
                                             <strong>Success!</strong> Product updated Successfully!.
                                        </div>";

                                 }else{
                                     echo "Category Not Updated!!";
                                 }
                            }
                      }

               ?> 
                </div>
                
               <div class="block copyblock"> 
                    <?php
                        $query="SELECT * FROM tbl_product WHERE pr_code='$id'";
                        $category=$db->select($query);
                        if ($category) {
                                               
                        while ($result=$category->fetch_assoc()) {
                    ?>
              
                 <form action="" method="post">
                  
                    <table class="form" >					
                        
                        <tr>
                            <td><b>Product Category:</b></td>
                            <td>
                            <input id="pr_category" type="text" placeholder="Enter Category" name="pr_category" value="<?php echo $result['pr_category'];?>"
                            </td>
                        </tr>
                         <tr>
                            <td><b>Product Code:</b></td>
                            <td>
                            <input id="pr_code" type="text" placeholder="Enter Product code" name="pr_code" value="<?php echo $result['pr_code'];?>"
                            </td>
                        </tr>
                    
                        <tr>
                            <td><b>Product Name:</b></td>
                            <td>
                            <input id="pr_name" type="text" placeholder="Product name" name="pr_name" value="<?php echo $result['pr_name'];?>"
                            </td>
                        </tr>   
                                
                        <tr>
                            <td><b>Product Description:</b></td>
                            <td>
                                <input id="pr_description" type="text" placeholder="Enter Product description" name="pr_description" value="<?php echo $result['pr_description'];?>"
                            </td>
                        </tr>
                        <tr>
                            <td><b>Supplier's Name:</b></td>
                            <td>
                                <input id="suplr_name" type="text" placeholder="Enter Supplier's Name" name="suplr_name" value="<?php echo $result['suplr_name'];?>"
                            </td>
                        </tr>
                         <tr>
                            <td><b>Memo No</b></td>
                            <td>
                            <input id="memo_no" type="text" placeholder="" name="memo_no" value="<?php echo $result['memo_no'];?>"
                            </td>
                        </tr>
                    
                        <tr>
                            <td><b>Quantity:</b></td>
                            <td>
                            <input id="quantity" type="text" placeholder="Enter quantity" name="quantity" value="<?php echo $result['quantity'];?>"
                            </td>
                        </tr>  
                         <tr>
                            <td><b>Discount:</b></td>
                            <td>
                            <input id="discount" type="text" placeholder="Enter Discount" name="discount" value="<?php echo $result['discount'];?>"
                            </td>
                        </tr>    
                                
                        <tr>
                            
                         <tr>
                            <td><b>Purchase Date:</b></td>
                            <td>
                              <input  type="date" placeholder="Applied date" name="datepicker"  class="form-control" value="<?php echo $result['datepicker'];?>"</input>
                           
                            </td>
                        </tr>
                    
                        <tr>
                            <td><b>Price (Original):</b></td>
                            <td>
                            <input id="org_price" type="text" placeholder="Original price" name="org_price" class='price'value="<?php echo $result['org_price'];?>"

                            </td>
                        </tr>   
                        
                                
                        <tr>
                            <td><b> Add Costing with Price :</b></td>
                            <td>
                                <input id="pr_costing" type="text" placeholder="Price with costing" name="pr_costing" class='adprice' value="<?php echo $result['pr_costing'];?>"
                                <td>
                               
                                </td>
                            </td>
                        </tr>
                      
                        <tr>
                            <td><b>Selling Price:</b></td>
                            <td>
                                <input id="sell_price" type="text" placeholder="Selling Price" name="sell_price" value="<?php echo $result['sell_price'];?>"
                            </td>
                        </tr>
                        
                        <tr>
                            <td></td>
                        </tr>
						<tr> 
                           
                            <td></td>
                            <td>
                               <input id="submit" type="submit" name="submit" value="Update" class="btn btn-primary"  />
                            </td>
                        </tr>
                    </table>
                    </form>
                    <?php } }?>
                </div>
            </div>
        </div>
        <script>
// we used jQuery 'keyup' to trigger the computation as the user type
$('.price').keyup(function () {
 
    // initialize the sum (total price) to zero
    var sum ;
    var sum1;
     
    // we use jQuery each() to loop through all the textbox with 'price' class
    // and compute the sum for each loop
    $('.price').each(function() {
        sum = Number($(this).val())+Number($(this).val())*.2;
        sum1=sum+sum*.3
    });
     
    // set the computed value to 'totalPrice' textbox
    $('#pr_costing').val(sum);
    $('#sell_price').val(sum1);
     
});
</script>
        
<?php include 'inc\footer.php';?>
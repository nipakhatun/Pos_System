<?php
 include '../lib/Session.php';
 Session::checkSession();
 ?>

 
<?php include '../config/config.php';?>
<?php include '../lib/Database.php';?>
<?php include '../helpers/Format.php';?>
<?php 
    $db=new Database();
    $fm=new Format();

?>
<?php
//call the FPDF library
require('fpdf17/fpdf.php');

//A4 width : 219mm
//default margin : 10mm each side
//writable horizontal : 219-(10*2)=189mm

//create pdf object
$pdf = new FPDF('P','mm','A4');
//add new page
$pdf->AddPage();



                    
$pdf->Cell(130 ,5,'GEMUL APPLIANCES.CO',0,0);
$pdf->Cell(59 ,5,'INVOICE',0,1);//end of line

//set font to arial, regular, 12pt
$pdf->SetFont('Arial','',12);

$pdf->Cell(130 ,5,'[Street Address]',0,0);
$pdf->Cell(59 ,5,'',0,1);//end of line
					
$pr_code=$_GET['pr_code'];
$query="SELECT * FROM tbl_sale
                        INNER JOIN tbl_product WHERE tbl_sale.prs_code=$pr_code";
					    $post=$db->select($query);
						if ($post) {
							
							 $result = mysqli_fetch_array($post);
							}


$pdf->Cell(130 ,5,'[City, Country, ZIP]',0,0);
$pdf->Cell(30 ,5,'Sell Date:',0,0);
$pdf->Cell(34 ,5,$result['sell_date'],0,1);//end of line

$pdf->Cell(130 ,5,'Phone [+12345678]',0,0);
$pdf->Cell(30 ,5,'Product Code:',0,0);
$pdf->Cell(34 ,5,$result['prs_code'],0,1);//end of line

$pdf->Cell(130 ,5,'Fax [+12345678]',0,0);
$pdf->Cell(30 ,5,'Customer ID:',0,0);
$pdf->Cell(34 ,5,$result['customer_id'],0,1);//end of line

//make a dummy empty cell as a vertical spacer
$pdf->Cell(189 ,10,'',0,1);//end of line

//billing address
$pdf->Cell(100 ,5,'Bill to',0,1);//end of line

//add dummy cell at beginning of each line for indentation
$pdf->Cell(10 ,5,'',0,0);
$pdf->Cell(90 ,5,'[Name]',0,1);

$pdf->Cell(10 ,5,'',0,0);
$pdf->Cell(90 ,5,'[Company Name]',0,1);

$pdf->Cell(10 ,5,'',0,0);
$pdf->Cell(90 ,5,'[Address]',0,1);

$pdf->Cell(10 ,5,'',0,0);
$pdf->Cell(90 ,5,'[Phone]',0,1);

//make a dummy empty cell as a vertical spacer
$pdf->Cell(189 ,10,'',0,1);//end of line
$query="SELECT * FROM  tbl_product WHERE tbl_product.pr_code=$pr_code";
					    $post=$db->select($query);
						if ($post) {
							
							 $rows = mysqli_fetch_array($post);
							}
$pdf->Cell(40 ,5,'Product Category',1,0);
$pdf->Cell(40 ,5,'Product Name',1,0);
$pdf->Cell(40 ,5,'Product Description',1,0);
$pdf->Cell(40 ,5,'quantity',1,0);
$pdf->Cell(35 ,5,'Sell price',1,0);


$pdf->Ln();

//invoice contents
$pdf->SetFont('Arial','B',12);
 $pdf->Cell(40 ,5,$rows['pr_category'],1,0);
$pdf->Cell(40 ,5,$rows['pr_name'],1,0);
$pdf->Cell(40 ,5,$rows['pr_description'],1,0);
$pdf->Cell(40 ,5,$result['quantity'],1,0);
$pdf->Cell(35 ,5,$result['price'],1,0);
$pdf->Ln();
$dis=$rows['discount']*100;
$pdf->Cell(130 ,5,'',0,0);
$pdf->Cell(25 ,5,'Discount:',0,0);
$pdf->Cell(5 ,5,'$',1,0);
$pdf->Cell(30 ,5,$dis,1,0,'R');//e
$pdf->Cell(5 ,5,'%',1,1,'R');//e

$pdf->Cell(130 ,5,'',0,0);
$pdf->Cell(25 ,5,'Total Price:',0,0);
$pdf->Cell(5 ,5,'$',1,0);
$pdf->Cell(35 ,5,$result['sale_price'],1,1,'R');//e





					
						
					$pdf->Output();
?>
         <script type="text/javascript">

        $(document).ready(function () {
            setupLeftMenu();

            $('.datatable').dataTable();
            setSidebarHeight();


        });
    </script>
    <script>
function myFunction() {
    window.print();
}
</script>

